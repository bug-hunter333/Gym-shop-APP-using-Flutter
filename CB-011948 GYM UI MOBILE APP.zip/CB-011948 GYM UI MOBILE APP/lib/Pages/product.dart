import 'package:flutter/material.dart';

void main() {
  runApp(const PrimeFitApp());
}

class PrimeFitApp extends StatelessWidget {
  const PrimeFitApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      theme: ThemeData.dark().copyWith(
        scaffoldBackgroundColor: Colors.black, // Set global background color to black
      ),
      home: const ProductPage(),
    );
  }
}

class ProductPage extends StatefulWidget {
  const ProductPage({super.key});

  @override
  _ProductPageState createState() => _ProductPageState();
}

class _ProductPageState extends State<ProductPage> {
  int _selectedIndex = 0;

  static final List<Widget> _screens = <Widget>[
    const DumbbellContent(),
    const CategoriesScreen(),
    const ProfileScreen(),
  ];

  void _onItemTapped(int index) {
    setState(() {
      _selectedIndex = index;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.black, // Ensuring background color stays black
      body: _screens[_selectedIndex],
      bottomNavigationBar: BottomNavigationBar(
        backgroundColor: Colors.black,
        selectedItemColor: Colors.green,
        unselectedItemColor: Colors.white,
        currentIndex: _selectedIndex,
        onTap: _onItemTapped,
        items: const [
          BottomNavigationBarItem(icon: Icon(Icons.fitness_center), label: 'Dumbbells'),
          BottomNavigationBarItem(icon: Icon(Icons.category), label: 'Categories'),
          BottomNavigationBarItem(icon: Icon(Icons.person), label: 'Profile'),
        ],
      ),
    );
  }
}

class DumbbellContent extends StatelessWidget {
  const DumbbellContent({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.black, // Background color black
      appBar: AppBar(
        title: const Text('Prime Fit'),
        backgroundColor: const Color.fromARGB(255, 51, 145, 82),
        centerTitle: true,
         titleTextStyle: const TextStyle(
            color: Color.fromARGB(255, 12, 12, 12),
            fontSize: 24,
            fontWeight: FontWeight.bold,
        ),
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Center(
              child: Image.asset("assets/icons/1.png", height: 200), // Replace with actual image
            ),
            const SizedBox(height: 20),
            const Text("Chrome Dumbells",
                style: TextStyle(color: Colors.white, fontSize: 22, fontWeight: FontWeight.bold)),
            const SizedBox(height: 10),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceEvenly,
              children: [
                ElevatedButton(
                  style: ElevatedButton.styleFrom(backgroundColor: Colors.green),
                  onPressed: () {},
                  child: const Text("Price: £79.99", style: TextStyle(color: Colors.black, fontSize: 18)),
                ),
                ElevatedButton(
                  style: ElevatedButton.styleFrom(backgroundColor: Colors.green),
                  onPressed: () {},
                  child: const Text("Quantity: 2", style: TextStyle(color: Colors.black, fontSize: 18)),
                ),
              ],
            ),
            const SizedBox(height: 20),
            const Text("Product Description:", style: TextStyle(color: Colors.white, fontSize: 18)),
            const SizedBox(height: 10),
            const Text(
              "High-quality adjustable dumbbells with a comfortable grip. Perfect for home workouts and gym training.",
              style: TextStyle(color: Colors.white70, fontSize: 16),
            ),
            const SizedBox(height: 20),
            const Center(
              child: Text("⭐ 4.8 (150 Reviews)", style: TextStyle(color: Colors.green, fontSize: 18)),
            ),
          ],
        ),
      ),
    );
  }
}

class CategoriesScreen extends StatelessWidget {
  const CategoriesScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.black, // Background color black
      appBar: AppBar(
        title: const Text('Categories'),
        backgroundColor: Colors.black,
      ),
      body: const Center(
        child: Text('Explore different gym equipment categories here!', style: TextStyle(color: Colors.white, fontSize: 18)),
      ),
    );
  }
}

class ProfileScreen extends StatelessWidget {
  const ProfileScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.black, // Background color black
      appBar: AppBar(
        title: const Text('Profile'),
        backgroundColor: Colors.black,
      ),
      body: const Center(
        child: Text('User profile details and settings.', style: TextStyle(color: Colors.white, fontSize: 18)),
      ),
    );
  }
}
