import 'package:flutter/material.dart';

class HomePage extends StatefulWidget {
  const HomePage({super.key});

  @override
  _HomePageState createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  final ScrollController _scrollController = ScrollController();
  int _selectedIndex = 0; // Track the selected bottom nav item

  @override
  void dispose() {
    _scrollController.dispose();
    super.dispose();
  }

  void _scrollToTop() {
    _scrollController.animateTo(
      0.0,
      duration: const Duration(milliseconds: 500),
      curve: Curves.easeInOut,
    );
  }

  void _onItemTapped(int index) {
    setState(() {
      _selectedIndex = index;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.black,
      appBar: AppBar(
        title: const Text('Prime Fit'),
        centerTitle: true,
        titleTextStyle: const TextStyle(
          color: Color.fromARGB(255, 12, 12, 12),
          fontSize: 24,
          fontWeight: FontWeight.bold,
        ),
        backgroundColor: const Color.fromARGB(255, 51, 145, 82),
        actions: [
          IconButton(
            icon: const Icon(Icons.arrow_upward, color: Colors.white),
            onPressed: _scrollToTop,
          ),
        ],
      ),
      body: _buildBody(), // Calls function to show content dynamically
      bottomNavigationBar: BottomNavigationBar(
        backgroundColor: Colors.black,
        selectedItemColor: Colors.greenAccent,
        unselectedItemColor: Colors.white70,
        currentIndex: _selectedIndex,
        onTap: _onItemTapped,
        items: const [
          BottomNavigationBarItem(
            icon: Icon(Icons.home),
            label: 'Home',
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.category),
            label: 'Categories',
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.person),
            label: 'Profile',
          ),
        ],
      ),
    );
  }

  Widget _buildBody() {
    switch (_selectedIndex) {
      case 0:
        return _homeScreen();
      case 1:
        return _categoriesScreen();
      case 2:
        return _profileScreen();
      default:
        return _homeScreen();
    }
  }

  Widget _homeScreen() {
    return SingleChildScrollView(
      controller: _scrollController,
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.center,
        children: [
          const Padding(
            padding: EdgeInsets.all(20),
            child: Text(
              'Welcome to Prime Fit',
              style: TextStyle(
                fontSize: 24,
                fontWeight: FontWeight.bold,
                color: Color.fromARGB(255, 173, 255, 47),
              ),
            ),
          ),
          const Text(
            'Gym Essentials',
            style: TextStyle(
              fontSize: 22,
              fontWeight: FontWeight.bold,
              color: Color.fromARGB(255, 17, 203, 132),
            ),
          ),
          const SizedBox(height: 16),
          GridView.builder(
            shrinkWrap: true,
            physics: const NeverScrollableScrollPhysics(),
            gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
              crossAxisCount: 2,
              crossAxisSpacing: 10,
              mainAxisSpacing: 10,
            ),
            padding: const EdgeInsets.all(16),
            itemCount: gymItems.length,
            itemBuilder: (context, index) {
              return gymItem(context, gymItems[index]['title'], gymItems[index]['icon']);
            },
          ),
          const Divider(color: Colors.white54, thickness: 1),
          const Padding(
            padding: EdgeInsets.all(16),
            child: Text(
              'Delivery Options',
              style: TextStyle(
                fontSize: 22,
                fontWeight: FontWeight.bold,
                color: Colors.white,
              ),
            ),
          ),
          ListView.builder(
            shrinkWrap: true,
            physics: const NeverScrollableScrollPhysics(),
            itemCount: deliveryOptions.length,
            itemBuilder: (context, index) {
              return deliveryItem(
                deliveryOptions[index]['title'],
                deliveryOptions[index]['icon'],
              );
            },
          ),
          const SizedBox(height: 20),
        ],
      ),
    );
  }

  Widget _categoriesScreen() {
    return const Center(
      child: Text(
        'Categories Screen',
        style: TextStyle(fontSize: 22, color: Colors.white),
      ),
    );
  }

  Widget _profileScreen() {
    return const Center(
      child: Text(
        'Profile Screen',
        style: TextStyle(fontSize: 22, color: Colors.white),
      ),
    );
  }

  Widget gymItem(BuildContext context, String title, IconData icon) {
    return GestureDetector(
      onTap: () {
        if (title == 'Dumbbells') {
          Navigator.push(
            context,
            MaterialPageRoute(builder: (context) => const DumbbellPage ()),
          );
        }
      },
      child: Card(
        color: Colors.grey[900],
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(icon, size: 50, color: Colors.greenAccent),
            const SizedBox(height: 10),
            Text(
              title,
              style: const TextStyle(
                fontSize: 18,
                color: Colors.white,
                fontWeight: FontWeight.bold,
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget deliveryItem(String title, IconData icon) {
    return Card(
      color: Colors.grey[850],
      margin: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
      child: ListTile(
        leading: Icon(icon, size: 40, color: Colors.orangeAccent),
        title: Text(
          title,
          style: const TextStyle(
            fontSize: 18,
            color: Colors.white,
            fontWeight: FontWeight.bold,
          ),
        ),
      ),
    );
  }
}

// Gym items list
final List<Map<String, dynamic>> gymItems = [
  {'title': 'Dumbbells', 'icon': Icons.fitness_center},
  {'title': 'Treadmill', 'icon': Icons.directions_run},
  {'title': 'Yoga Mat', 'icon': Icons.self_improvement},
  {'title': 'Boxing Gloves', 'icon': Icons.sports_mma},
];

// Delivery options list
final List<Map<String, dynamic>> deliveryOptions = [
  {'title': 'Standard Delivery (3-5 Days)', 'icon': Icons.local_shipping},
  {'title': 'Express Delivery (1-2 Days)', 'icon': Icons.delivery_dining},
  {'title': 'Same-Day Delivery', 'icon': Icons.flash_on},
  {'title': 'In-Store Pickup', 'icon': Icons.store},
];










// Dumbbells UI Screen




class DumbbellPage extends StatefulWidget {
  const DumbbellPage({super.key});

  @override
  _DumbbellPageState createState() => _DumbbellPageState();
}

class _DumbbellPageState extends State<DumbbellPage> {
  int _selectedIndex = 0;

  static final List<Widget> _screens = <Widget>[
    DumbbellContent(),
    CategoriesScreen(), // Ensure this class is defined
    ProfileScreen(), // Ensure this class is defined
  ];

  void _onItemTapped(int index) {
    setState(() {
      _selectedIndex = index;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: _screens[_selectedIndex],
      bottomNavigationBar: BottomNavigationBar(
        backgroundColor: Colors.black,
        selectedItemColor: Colors.green,
        unselectedItemColor: Colors.white,
        currentIndex: _selectedIndex,
        onTap: _onItemTapped,
        items: const [
          BottomNavigationBarItem(icon: Icon(Icons.fitness_center), label: 'Dumbbells'),
          BottomNavigationBarItem(icon: Icon(Icons.category), label: 'Categories'),
          BottomNavigationBarItem(icon: Icon(Icons.person), label: 'Profile'),
        ],
      ),
    );
  }
}

class ProfileScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Profile'),
      ),
      body: Center(
        child: const Text('Profile Screen'),
      ),
    );
  }
}

class CategoriesScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Categories'),
      ),
      body: Center(
        child: const Text('Categories Screen'),
      ),
    );
  }
}

class DumbbellContent extends StatelessWidget {
  const DumbbellContent({super.key});

  @override
  Widget build(BuildContext context) {
    final List<Map<String, dynamic>> products = [
      {
        'name': 'Adjustable Dumbbell',
        'price': '\$99.99',
        'image': 'assets/icons/1.png',
        'description': 'High-quality adjustable dumbbell set.',
      },
      {
        'name': 'Rubber Hex Dumbbell',
        'price': '\$49.99',
        'image': 'assets/icons/2.png',
        'description': 'Durable rubber hex dumbbell.',
      },
      {
        'name': 'Neoprene Dumbbell',
        'price': '\$29.99',
        'image': 'assets/icons/3.png',
        'description': 'Lightweight neoprene coated dumbbell.',
      },
      {
        'name': 'Cast Iron Dumbbell',
        'price': '\$39.99',
        'image': 'assets/icons/4.png',
        'description': 'Classic cast iron dumbbell.',
      },
    ];

    return Scaffold(
      backgroundColor: Colors.black,
      appBar: AppBar(
        title: const Text('Prime Fit'),
        centerTitle: true,
        backgroundColor: const Color.fromARGB(255, 51, 145, 82),
      ),
      body: SingleChildScrollView(
        child: Padding(
          padding: const EdgeInsets.all(16.0),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const Text(
                'Dumbbells',
                style: TextStyle(
                  color: Colors.white,
                  fontSize: 20,
                  fontWeight: FontWeight.bold,
                ),
              ),
              const SizedBox(height: 10),
              GridView.builder(
                shrinkWrap: true,
                physics: const NeverScrollableScrollPhysics(),
                gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                  crossAxisCount: 2,
                  crossAxisSpacing: 10,
                  mainAxisSpacing: 10,
                  childAspectRatio: 0.75,
                ),
                itemCount: products.length,
                itemBuilder: (context, index) {
                  final product = products[index];
                  return GestureDetector(
                    onTap: () {
                      Navigator.push(
                        context,
                        MaterialPageRoute(
                          builder: (context) => ProductDetailPage(product: product),
                        ),
                      );
                    },
                    child: Card(
                      color: Colors.grey[900],
                      elevation: 5,
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(10),
                      ),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Expanded(
                            child: ClipRRect(
                              borderRadius: const BorderRadius.vertical(
                                top: Radius.circular(10),
                              ),
                              child: Image.asset(
                                product['image'],
                                fit: BoxFit.cover,
                                width: double.infinity,
                              ),
                            ),
                          ),
                          Padding(
                            padding: const EdgeInsets.all(8.0),
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Text(
                                  product['name'],
                                  style: const TextStyle(
                                    color: Colors.white,
                                    fontSize: 18,
                                    fontWeight: FontWeight.bold,
                                  ),
                                ),
                                const SizedBox(height: 4),
                                Text(
                                  product['price'],
                                  style: const TextStyle(
                                    color: Colors.green,
                                    fontSize: 16,
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ],
                      ),
                    ),
                  );
                },
              ),
            ],
          ),
        ),
      ),
    );
  }
}


//Dummbbells Product Page 



class ProductDetailPage extends StatelessWidget {
  final Map<String, dynamic> product;
  const ProductDetailPage({super.key, required this.product});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.black, // Background color black
      appBar: AppBar(
        title: const Text('Prime Fit'),
        backgroundColor: const Color.fromARGB(255, 51, 145, 82),
        centerTitle: true,
        titleTextStyle: const TextStyle(
          color: Color.fromARGB(255, 12, 12, 12),
          fontSize: 24,
          fontWeight: FontWeight.bold,
        ),
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Center(
              child: Image.asset("assets/icons/1.png", height: 200), // Replace with actual image
            ),
            const SizedBox(height: 20),
            const Text(
              "Chrome Dumbbells",
              style: TextStyle(color: Colors.white, fontSize: 22, fontWeight: FontWeight.bold),
            ),
            const SizedBox(height: 10),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceEvenly,
              children: [
                ElevatedButton(
                  style: ElevatedButton.styleFrom(backgroundColor: Colors.green),
                  onPressed: () {},
                  child: const Text("Price: £79.99", style: TextStyle(color: Colors.black, fontSize: 18)),
                ),
                ElevatedButton(
                  style: ElevatedButton.styleFrom(backgroundColor: Colors.green),
                  onPressed: () {
                    // Navigate to CheckoutPage
                    Navigator.push(
                      context,
                      MaterialPageRoute(builder: (context) => const CheckoutPage()),
                    );
                  },
                  child: const Text("Checkout", style: TextStyle(color: Colors.black, fontSize: 18)),
                ),
              ],
            ),
            const SizedBox(height: 20),
            const Text("Product Description:", style: TextStyle(color: Colors.white, fontSize: 18)),
            const SizedBox(height: 10),
            const Text(
              "High-quality adjustable dumbbells with a comfortable grip. Perfect for home workouts and gym training.",
              style: TextStyle(color: Colors.white70, fontSize: 16),
            ),
            const SizedBox(height: 20),
            const Center(
              child: Text("⭐ 4.8 (150 Reviews)", style: TextStyle(color: Colors.green, fontSize: 18)),
            ),
          ],
        ),
      ),
    );
  }
}








// Checkout Page


class CheckoutPage extends StatelessWidget {
  const CheckoutPage({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      theme: ThemeData.dark(),
      home: const PurchasePage(),
    );
  }
}

class PurchasePage extends StatefulWidget {
  const PurchasePage({super.key});

  @override
  _CheckoutPageState createState() => _CheckoutPageState();
}

class _CheckoutPageState extends State<PurchasePage> {
  int quantity = 1;
  double price = 79.99;

  void _incrementQuantity() {
    setState(() {
      quantity++;
    });
  }

  void _decrementQuantity() {
    if (quantity > 1) {
      setState(() {
        quantity--;
      });
    }
  }

  void _placeOrder() {
    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(
        content: Text("Order placed successfully!"),
        backgroundColor: Colors.green,
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    double total = price * quantity;

    return Scaffold(
      appBar: AppBar(
        leading: IconButton(
          icon: const Icon(Icons.arrow_back, color: Colors.black),
          onPressed: () {
            Navigator.pop(context); // Go back to the previous page
          },
        ),
        title: const Text("Checkout"),
        centerTitle: true,
        backgroundColor: const Color.fromARGB(255, 51, 145, 82),
        titleTextStyle: const TextStyle(
          color: Colors.black,
          fontSize: 24,
          fontWeight: FontWeight.bold,
        ),
      ),
      backgroundColor: Colors.black,
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // Product Section with Image
            Container(
              padding: const EdgeInsets.all(12),
              decoration: BoxDecoration(
                color: Colors.grey[900],
                borderRadius: BorderRadius.circular(10),
              ),
              child: Row(
                children: [
                  ClipRRect(
                    borderRadius: BorderRadius.circular(10),
                    child: Image.asset(
                      'assets/icons/1.png',
                      height: 60,
                      width: 60,
                      fit: BoxFit.cover,
                    ),
                  ),
                  const SizedBox(width: 15),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        const Text("Dumbbells (Pair)", style: TextStyle(color: Colors.white, fontSize: 18)),
                        Text("£${price.toStringAsFixed(2)}", style: const TextStyle(color: Colors.green, fontSize: 16)),
                      ],
                    ),
                  ),
                  Row(
                    children: [
                      IconButton(
                        icon: const Icon(Icons.remove_circle, color: Colors.white),
                        onPressed: _decrementQuantity,
                      ),
                      Text("$quantity", style: const TextStyle(color: Colors.white, fontSize: 18)),
                      IconButton(
                        icon: const Icon(Icons.add_circle, color: Colors.green),
                        onPressed: _incrementQuantity,
                      ),
                    ],
                  ),
                ],
              ),
            ),

            const SizedBox(height: 20),

            // Order Summary
            Container(
              padding: const EdgeInsets.all(12),
              decoration: BoxDecoration(
                color: Colors.grey[900],
                borderRadius: BorderRadius.circular(10),
              ),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  const Text("Total", style: TextStyle(color: Colors.white, fontSize: 18)),
                  Text("£${total.toStringAsFixed(2)}", style: const TextStyle(color: Colors.green, fontSize: 18)),
                ],
              ),
            ),

            const SizedBox(height: 30),

            // Place Order Button
            Center(
              child: ElevatedButton(
                style: ElevatedButton.styleFrom(
                  backgroundColor: Colors.green,
                  padding: const EdgeInsets.symmetric(horizontal: 50, vertical: 15),
                ),
                onPressed: _placeOrder,
                child: const Text("Place Order", style: TextStyle(color: Colors.black, fontSize: 18)),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
